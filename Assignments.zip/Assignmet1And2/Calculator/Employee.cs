﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{

    class Employee
    {
        private double HRA;
        private double TA;
        private double DA;
        private double PF;
        private double TDS;
        private double netsal;
        private double grosssal;

        private int empno
        {
            get;
            set;
        }
         string empname
        {
            get;
            set;
        }
        private double salary
        {
            get;
            set;
        }
        
        public void Salarucalculation()
        {
          
            Console.WriteLine("Enter employee name " + empname + "/t enter employee number:" + empno + "enter employee salary:" + salary  );
        }
        public void cal()
        {

            if (salary <= 5000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                grosssal = HRA + DA + TA;
                
            }
            else if (salary < 10000)
            {

                HRA = (salary * 15) / 100;
                TA = (salary * 10) / 100;
                DA = (salary * 20) / 100;
                grosssal = HRA + DA + TA;

            }
            else if (salary < 15000)
            {
                HRA = (salary * 20) / 100;
                TA =(salary * 15) / 100;
                DA = (salary * 25) / 100;

            }
            else if (salary < 20000)
            {
                HRA = (salary * 25) / 100;
                TA = (salary * 20) / 100;
                DA = (salary * 30) / 100;
                grosssal = HRA + DA + TA;

            }
            else if (salary >= 20000)
            {
                HRA = (salary * 30) / 100;
                TA = (salary * 25) / 100;
                DA = (salary * 35) / 100;
                grosssal = HRA + DA + TA;

            }
           

        }
        void CalculteSalaary()
        {
            PF = (grosssal * 10) / 100;
            TDS = (grosssal * 18) / 100;
            netsal = grosssal - (PF + TDS);

        }
        public static void main(string[] arg)

                {
            Employee em = new Employee();
                {
                em.Salarucalculation();
                em.cal();
                em.CalculteSalaary();
               


                }
                
        
        
                }
          }
        }   



