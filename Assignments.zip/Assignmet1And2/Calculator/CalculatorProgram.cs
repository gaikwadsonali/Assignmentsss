﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{
    class CalculatorProgram
    {
        static void Main(string[] args)
        {
            int result;
            String value;

            do
            {
                Console.WriteLine("First no");
                int no1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Second no");
                int no2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("ENter Operation You Want To perform : / * - +");
                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "+":

                        result = no1 + no2;
                        Console.WriteLine("Addition :" + result);
                        break;

                    case "-":

                        result = no1 - no2;
                        Console.WriteLine("Substraction :" + result);
                        break;
                    case "*":

                        result = no1 * no2;
                        Console.WriteLine("Multiplication :" + result);
                        break;
                    case "/":

                        result = no1 + no2;
                        Console.WriteLine("Division :" + result);

                        break;
                    default:
                        Console.WriteLine("Wrong input");
                        break;
                }
                Console.ReadLine();
                Console.WriteLine("Do u want to continue....? press y or n");
        value = Console.ReadLine();

            }
            while (value == "Y" || value == "y");
        }
    }
}