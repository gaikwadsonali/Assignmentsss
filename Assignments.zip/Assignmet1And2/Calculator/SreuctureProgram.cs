﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structuree
{


    struct Books
    {
        public string title;
        public string price;
        public string booktype;
        public int book_id;
    };

    public class testStructure
    {
        public static void Main(string[] args)
        {
            Books Book1;
            Books Book2;


            Book1.title = "magzine";
            Book1.price = "500";
            Book1.booktype = "magzine ";
            Book1.book_id = 6495407;


            Book2.title = "Telecom Billing";
            Book2.price = "800";
            Book2.booktype = "misslanious";
            Book2.book_id = 6495700;


            Console.WriteLine("Book 1 title : {0}", Book1.title);
            Console.WriteLine("Book 1 price : {0}", Book1.price);
            Console.WriteLine("Book 1 book tyoe : {0}", Book1.booktype);
            Console.WriteLine("Book 1 book_id :{0}", Book1.book_id);

            /* print Book2 info */
            Console.WriteLine("Book 2 title : {0}", Book2.title);
            Console.WriteLine("Book 2 author : {0}", Book2.price);
            Console.WriteLine("Book 2 subject : {0}", Book2.booktype);
            Console.WriteLine("Book 2 book_id : {0}", Book2.book_id);

            Console.ReadKey();
        }
    }
}