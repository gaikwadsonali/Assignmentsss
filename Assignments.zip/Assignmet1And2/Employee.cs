﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator
{

    class Employee
    {
        private double HRA;
        private double TA;
        private double DA;
        private double PF;
        private double TDS;
        private double netsal;
        private double grosssal;

        private int empno
        {
            get;set;
        }
       private  string empname {
            get; set;

        }
        private double salary
        {
            get; set;
        }
        
        public void Salarucalculation()
        {
            Console.WriteLine("enter basic salary" + salary);
            salary = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter employee name " + empname );
            empname=Console.ReadLine();
            Console.WriteLine("enter employee number:" + empno);
            empno=Convert.ToInt32(Console.ReadLine());
               
        }
        public void cal()
        {

            if (salary <= 5000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                grosssal = HRA + DA + TA;
                Console.WriteLine("Gross salary is:" + grosssal);

            }
            else if (salary < 10000)
            {

                HRA = (salary * 15) / 100;
                TA = (salary * 10) / 100;
                DA = (salary * 20) / 100;
                grosssal = HRA + DA + TA;
                Console.WriteLine("Gross salary is:" + grosssal);
            }
            else if (salary < 15000)
            {
                HRA = (salary * 20) / 100;
                TA =(salary * 15) / 100;
                DA = (salary * 25) / 100;
                grosssal = HRA + DA + TA;
                Console.WriteLine("Gross salary is:" + grosssal);
            }
            else if (salary < 20000)
            {
                HRA = (salary * 25) / 100;
                TA = (salary * 20) / 100;
                DA = (salary * 30) / 100;
                grosssal = HRA + DA + TA;
                Console.WriteLine("Gross salary is:" + grosssal);
            }
            else if (salary >= 20000)
            {
                HRA = (salary * 30) / 100;
                TA = (salary * 25) / 100;
                DA = (salary * 35) / 100;
                grosssal = HRA + DA + TA;
                Console.WriteLine("Gross salary is:" + grosssal);

            }
           

        }
        void CalculteSalaary()
        {
            PF = (grosssal * 10) / 100;
            TDS = (grosssal * 18) / 100;
            netsal = grosssal - (PF + TDS);
            Console.WriteLine("net salary is:" +netsal);
        }

        static void Main(string[] args)

        {
            Employee em = new Employee();
                {
                em.Salarucalculation();
                em.cal();
                em.CalculteSalaary();
                Console.ReadKey();



                }
                
        
        
                }
          }
        }   



